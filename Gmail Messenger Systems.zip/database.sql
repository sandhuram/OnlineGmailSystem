
drop database pro;

create database pro;

use pro;


DROP TABLE IF EXISTS `msgdtls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `msgdtls` (
  `msgid` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `time` datetime NOT NULL,
  `senderid` int(11) NOT NULL,
  `sender` char(50) NOT NULL,
  `sendermail` char(50) NOT NULL,
  `recieverid` int(11) NOT NULL,
  `reciever` char(25) NOT NULL,
  `msg` blob,
  `recievermail` char(50) NOT NULL,
  `recieverdel` char(5) DEFAULT NULL,
  `senderdel` char(5) DEFAULT NULL,
  PRIMARY KEY (`msgid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;



DROP TABLE IF EXISTS `userdtls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userdtls` (
  `user_id` int(11) NOT NULL,
  `user_name` char(50) NOT NULL,
  `name` char(50) NOT NULL,
  `email` char(50) NOT NULL,
  `password` char(50) NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_name` (`user_name`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

